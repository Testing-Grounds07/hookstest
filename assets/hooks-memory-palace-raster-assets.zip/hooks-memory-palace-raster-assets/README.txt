Hooks Memory Palace — Raster Asset Package

Copy the contents of the assets/ directory into the GitHub repository at:
  /assets/

Primary Scene 2 assets:
  bg_classroom.webp
  bg_window.webp
  bg_right.webp
  books_alpha.webp
  morrison_alpha.webp
  plant_wilted_alpha.webp
  plant_healthy_alpha.webp
  syllabus_alpha.webp
  podium_alpha.webp
  mug_alpha.webp
  light_rays_alpha.webp
  dust_alpha.webp

Additional motion/transition assets:
  leaves_alpha.webp
  papers_alpha.webp
  door_open_alpha.webp
  door_closed_alpha.webp
  hallway.png

These are the generated raster/WebP assets intended to replace the proof-of-concept SVG artwork.
